import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BookOpen, 
  Users, 
  ShoppingCart, 
  DollarSign,
  Plus,
  Edit,
  Trash2,
  Eye,
  TrendingUp,
  Package
} from "lucide-react";

// Mock data - replace with real API data
const dashboardStats = [
  {
    title: "Total Books",
    value: "2,847",
    change: "+12%",
    icon: BookOpen,
    color: "text-blue-600"
  },
  {
    title: "Total Users",
    value: "1,249",
    change: "+8%",
    icon: Users,
    color: "text-green-600"
  },
  {
    title: "Orders Today",
    value: "47",
    change: "+23%",
    icon: ShoppingCart,
    color: "text-purple-600"
  },
  {
    title: "Revenue",
    value: "$12,847",
    change: "+15%",
    icon: DollarSign,
    color: "text-yellow-600"
  }
];

const recentOrders = [
  {
    id: "ORD-001",
    customer: "John Doe",
    email: "john@example.com",
    items: 2,
    total: 35.98,
    status: "completed",
    date: "2024-01-15"
  },
  {
    id: "ORD-002",
    customer: "Jane Smith",
    email: "jane@example.com",
    items: 1,
    total: 18.99,
    status: "processing",
    date: "2024-01-15"
  },
  {
    id: "ORD-003",
    customer: "Bob Johnson",
    email: "bob@example.com",
    items: 3,
    total: 52.97,
    status: "shipped",
    date: "2024-01-14"
  }
];

const inventoryAlerts = [
  { book: "The Seven Husbands of Evelyn Hugo", stock: 3, status: "low" },
  { book: "Atomic Habits", stock: 0, status: "out" },
  { book: "The Silent Patient", stock: 5, status: "low" }
];

export const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-success text-success-foreground">Completed</Badge>;
      case "processing":
        return <Badge className="bg-accent text-accent-foreground">Processing</Badge>;
      case "shipped":
        return <Badge variant="secondary">Shipped</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getStockBadge = (status: string) => {
    switch (status) {
      case "out":
        return <Badge variant="destructive">Out of Stock</Badge>;
      case "low":
        return <Badge className="bg-orange-500 text-white">Low Stock</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-bold font-serif text-foreground">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground mt-2">
            Manage your bookstore operations
          </p>
        </div>
        <Button variant="hero">
          <Plus className="h-4 w-4 mr-2" />
          Add New Book
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="books">Books</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {dashboardStats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="shadow-book hover:shadow-elegant transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">
                          {stat.title}
                        </p>
                        <p className="text-2xl font-bold text-foreground">
                          {stat.value}
                        </p>
                        <p className="text-sm text-success flex items-center gap-1 mt-1">
                          <TrendingUp className="h-3 w-3" />
                          {stat.change} from last month
                        </p>
                      </div>
                      <div className={`p-3 rounded-lg bg-gradient-primary`}>
                        <Icon className="h-6 w-6 text-primary-foreground" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Recent Orders and Inventory Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Orders */}
            <Card className="shadow-book">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Recent Orders
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <p className="font-medium text-foreground">{order.id}</p>
                          {getStatusBadge(order.status)}
                        </div>
                        <p className="text-sm text-muted-foreground">{order.customer}</p>
                        <p className="text-sm text-muted-foreground">{order.email}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-foreground">${order.total.toFixed(2)}</p>
                        <p className="text-sm text-muted-foreground">{order.items} items</p>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  View All Orders
                </Button>
              </CardContent>
            </Card>

            {/* Inventory Alerts */}
            <Card className="shadow-book">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Inventory Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {inventoryAlerts.map((alert, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-foreground line-clamp-2">
                          {alert.book}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Stock: {alert.stock} units
                        </p>
                      </div>
                      <div>
                        {getStockBadge(alert.status)}
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  Manage Inventory
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="books" className="space-y-6">
          <Card className="shadow-book">
            <CardHeader>
              <CardTitle>Book Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BookOpen className="h-24 w-24 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  Book Management
                </h3>
                <p className="text-muted-foreground mb-6">
                  Add, edit, and manage your book inventory here.
                </p>
                <div className="flex gap-4 justify-center">
                  <Button variant="hero">
                    <Plus className="h-4 w-4 mr-2" />
                    Add New Book
                  </Button>
                  <Button variant="outline">
                    Import Books
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders" className="space-y-6">
          <Card className="shadow-book">
            <CardHeader>
              <CardTitle>Order Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <ShoppingCart className="h-24 w-24 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  Order Management
                </h3>
                <p className="text-muted-foreground mb-6">
                  View and manage customer orders, process shipments, and handle returns.
                </p>
                <Button variant="hero">
                  View All Orders
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <Card className="shadow-book">
            <CardHeader>
              <CardTitle>User Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Users className="h-24 w-24 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  User Management
                </h3>
                <p className="text-muted-foreground mb-6">
                  Manage customer accounts, view user analytics, and handle support requests.
                </p>
                <Button variant="hero">
                  View All Users
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Star, 
  ShoppingCart, 
  Heart, 
  Share2, 
  Truck,
  Shield,
  RotateCcw,
  ChevronLeft
} from "lucide-react";

// Mock book data - replace with real API call
const mockBook = {
  id: "1",
  title: "The Seven Husbands of Evelyn Hugo",
  author: "Taylor Jenkins Reid",
  price: 16.99,
  originalPrice: 19.99,
  genre: "Contemporary Fiction",
  rating: 4.8,
  reviewCount: 2847,
  imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=600&fit=crop",
  isNew: false,
  isBestseller: true,
  isOnSale: true,
  stock: 12,
  isbn: "978-1501161933",
  pages: 400,
  publisher: "Atria Books",
  publishDate: "June 13, 2017",
  language: "English",
  description: "From the New York Times bestselling author of Daisy Jones & The Six—an entrancing and 'wildly addictive' (Entertainment Weekly) novel about a reclusive Hollywood icon finally ready to tell her story. Aging and reclusive Hollywood movie icon Evelyn Hugo is finally ready to tell the truth about her glamorous and scandalous life. But when she chooses unknown magazine reporter Monique Grant for the job, no one is more astounded than Monique herself. Why her? Why now?",
  features: [
    "New York Times Bestseller",
    "Over 1 million copies sold",
    "Soon to be a Netflix film",
    "Book club favorite"
  ]
};

export const BookDetail = () => {
  const { id } = useParams();
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);

  const handleAddToCart = () => {
    // Add to cart logic here
    console.log(`Adding ${quantity} copies to cart`);
  };

  const discountPercentage = mockBook.originalPrice 
    ? Math.round(((mockBook.originalPrice - mockBook.price) / mockBook.originalPrice) * 100)
    : 0;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <Link to="/books" className="hover:text-primary transition-colors">Books</Link>
        <span>/</span>
        <span className="text-foreground">{mockBook.title}</span>
      </div>

      {/* Back Button */}
      <Link to="/books">
        <Button variant="ghost" className="mb-6">
          <ChevronLeft className="h-4 w-4 mr-2" />
          Back to Books
        </Button>
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Book Image */}
        <div className="space-y-4">
          <div className="relative">
            <img
              src={mockBook.imageUrl}
              alt={mockBook.title}
              className="w-full max-w-md mx-auto rounded-lg shadow-elegant"
            />
            {mockBook.isOnSale && discountPercentage > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute top-4 left-4"
              >
                -{discountPercentage}% OFF
              </Badge>
            )}
          </div>
        </div>

        {/* Book Details */}
        <div className="space-y-6">
          {/* Title and Author */}
          <div>
            <h1 className="text-4xl font-bold font-serif text-foreground mb-2">
              {mockBook.title}
            </h1>
            <p className="text-xl text-muted-foreground mb-4">
              by {mockBook.author}
            </p>
            
            {/* Rating */}
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(mockBook.rating)
                        ? "fill-accent text-accent"
                        : "text-muted-foreground"
                    }`}
                  />
                ))}
              </div>
              <span className="text-foreground font-medium">
                {mockBook.rating}
              </span>
              <span className="text-muted-foreground">
                ({mockBook.reviewCount.toLocaleString()} reviews)
              </span>
            </div>

            {/* Badges */}
            <div className="flex flex-wrap gap-2 mb-6">
              {mockBook.isBestseller && (
                <Badge className="bg-accent text-accent-foreground">
                  Bestseller
                </Badge>
              )}
              {mockBook.isNew && (
                <Badge variant="destructive">New Release</Badge>
              )}
              <Badge variant="outline">{mockBook.genre}</Badge>
            </div>
          </div>

          {/* Price */}
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <span className="text-3xl font-bold text-foreground">
                ${mockBook.price.toFixed(2)}
              </span>
              {mockBook.originalPrice && mockBook.originalPrice > mockBook.price && (
                <span className="text-xl text-muted-foreground line-through">
                  ${mockBook.originalPrice.toFixed(2)}
                </span>
              )}
            </div>
            {mockBook.stock <= 5 && (
              <p className="text-destructive font-medium">
                Only {mockBook.stock} left in stock!
              </p>
            )}
          </div>

          {/* Add to Cart Section */}
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                {/* Quantity Selector */}
                <div className="flex items-center gap-4">
                  <label className="font-medium">Quantity:</label>
                  <div className="flex items-center border rounded-lg">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                      className="rounded-none"
                    >
                      -
                    </Button>
                    <span className="px-4 py-2 min-w-12 text-center">
                      {quantity}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setQuantity(Math.min(mockBook.stock, quantity + 1))}
                      disabled={quantity >= mockBook.stock}
                      className="rounded-none"
                    >
                      +
                    </Button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    variant="hero"
                    size="lg"
                    onClick={handleAddToCart}
                    disabled={mockBook.stock === 0}
                    className="flex-1"
                  >
                    <ShoppingCart className="h-5 w-5 mr-2" />
                    Add to Cart
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => setIsWishlisted(!isWishlisted)}
                  >
                    <Heart 
                      className={`h-5 w-5 ${
                        isWishlisted ? "fill-destructive text-destructive" : ""
                      }`} 
                    />
                  </Button>
                  <Button variant="outline" size="lg">
                    <Share2 className="h-5 w-5" />
                  </Button>
                </div>

                {/* Shipping Info */}
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-success">
                    <Truck className="h-4 w-4" />
                    <span>Free shipping on orders over $25</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Shield className="h-4 w-4" />
                    <span>Secure payment with SSL encryption</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <RotateCcw className="h-4 w-4" />
                    <span>30-day return policy</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Book Details */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Book Details</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">ISBN:</span>
                  <p className="font-medium">{mockBook.isbn}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Pages:</span>
                  <p className="font-medium">{mockBook.pages}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Publisher:</span>
                  <p className="font-medium">{mockBook.publisher}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Published:</span>
                  <p className="font-medium">{mockBook.publishDate}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Language:</span>
                  <p className="font-medium">{mockBook.language}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Genre:</span>
                  <p className="font-medium">{mockBook.genre}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Description */}
      <div className="mt-12">
        <Card>
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold mb-4">Description</h3>
            <p className="text-muted-foreground leading-relaxed">
              {mockBook.description}
            </p>
            
            {mockBook.features.length > 0 && (
              <div className="mt-6">
                <h4 className="font-semibold mb-3">Features</h4>
                <ul className="space-y-2">
                  {mockBook.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-accent" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
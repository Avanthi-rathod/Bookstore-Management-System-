import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { BookCard } from "@/components/BookCard";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  BookOpen, 
  Users, 
  Award, 
  TrendingUp,
  Star
} from "lucide-react";
import heroImage from "@/assets/bookstore-hero.jpg";

// Mock data - replace with real data from API
const featuredBooks = [
  {
    id: "1",
    title: "The Seven Husbands of Evelyn Hugo",
    author: "Taylor Jenkins Reid",
    price: 16.99,
    originalPrice: 19.99,
    genre: "Contemporary Fiction",
    rating: 4.8,
    reviewCount: 2847,
    imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=300&h=400&fit=crop",
    isNew: false,
    isBestseller: true,
    isOnSale: true,
    stock: 12
  },
  {
    id: "2",
    title: "Atomic Habits",
    author: "James Clear",
    price: 18.99,
    genre: "Self-Help",
    rating: 4.9,
    reviewCount: 5234,
    imageUrl: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=300&h=400&fit=crop",
    isNew: false,
    isBestseller: true,
    isOnSale: false,
    stock: 8
  },
  {
    id: "3",
    title: "The Silent Patient",
    author: "Alex Michaelides",
    price: 15.99,
    originalPrice: 17.99,
    genre: "Thriller",
    rating: 4.6,
    reviewCount: 1923,
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=400&fit=crop",
    isNew: true,
    isBestseller: false,
    isOnSale: true,
    stock: 15
  },
  {
    id: "4",
    title: "Educated",
    author: "Tara Westover",
    price: 17.99,
    genre: "Memoir",
    rating: 4.7,
    reviewCount: 3456,
    imageUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop",
    isNew: false,
    isBestseller: true,
    isOnSale: false,
    stock: 6
  }
];

const categories = [
  { name: "Fiction", count: 2847, icon: BookOpen },
  { name: "Non-Fiction", count: 1923, icon: TrendingUp },
  { name: "Romance", count: 1456, icon: Star },
  { name: "Mystery", count: 1234, icon: Award },
];

const stats = [
  { label: "Books Available", value: "50,000+", icon: BookOpen },
  { label: "Happy Readers", value: "25,000+", icon: Users },
  { label: "5-Star Reviews", value: "95%", icon: Star },
  { label: "Years in Business", value: "15", icon: Award },
];

export const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[70vh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-primary/90 via-primary/70 to-transparent" />
        </div>
        
        <div className="relative z-10 text-center text-primary-foreground max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-bold font-serif mb-6 drop-shadow-lg">
            Welcome to
            <span className="block bg-gradient-accent bg-clip-text text-transparent">
              BookVault
            </span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 drop-shadow-md max-w-2xl mx-auto">
            Discover your next favorite book from our curated collection of literature, 
            bestsellers, and hidden gems.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/books">
              <Button variant="accent" size="lg" className="text-lg px-8">
                Browse Books
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/bestsellers">
              <Button variant="outline" size="lg" className="text-lg px-8 bg-background/20 backdrop-blur border-primary-foreground text-primary-foreground hover:bg-background/30">
                View Bestsellers
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-gradient-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-book">
                    <Icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-2">
                    {stat.value}
                  </div>
                  <div className="text-muted-foreground">
                    {stat.label}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Books Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold font-serif text-foreground mb-4">
              Featured Books
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Handpicked selections from our bestsellers and new arrivals
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {featuredBooks.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>

          <div className="text-center">
            <Link to="/books">
              <Button variant="hero" size="lg">
                View All Books
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold font-serif text-foreground mb-4">
              Browse by Category
            </h2>
            <p className="text-xl text-muted-foreground">
              Find books in your favorite genres
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => {
              const Icon = category.icon;
              return (
                <Link
                  key={index}
                  to={`/books?category=${category.name.toLowerCase()}`}
                  className="group"
                >
                  <div className="bg-card p-6 rounded-lg shadow-book hover:shadow-elegant transition-all duration-300 group-hover:-translate-y-1 text-center">
                    <div className="bg-gradient-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:shadow-glow transition-all duration-300">
                      <Icon className="h-8 w-8 text-primary-foreground" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                      {category.name}
                    </h3>
                    <Badge variant="secondary" className="text-sm">
                      {category.count.toLocaleString()} books
                    </Badge>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gradient-hero">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto text-primary-foreground">
            <h2 className="text-4xl font-bold font-serif mb-4">
              Stay Updated
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Get notified about new releases, special offers, and book recommendations
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg bg-background/20 backdrop-blur border border-primary-foreground/30 text-primary-foreground placeholder:text-primary-foreground/70 focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <Button variant="accent" size="lg">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
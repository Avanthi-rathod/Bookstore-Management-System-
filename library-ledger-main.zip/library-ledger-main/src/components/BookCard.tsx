import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Heart, ShoppingCart, Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface BookCardProps {
  book: {
    id: string;
    title: string;
    author: string;
    price: number;
    originalPrice?: number;
    genre: string;
    rating: number;
    reviewCount: number;
    imageUrl: string;
    isNew?: boolean;
    isBestseller?: boolean;
    isOnSale?: boolean;
    stock: number;
  };
  className?: string;
}

export const BookCard = ({ book, className }: BookCardProps) => {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation when clicking the button
    setIsAddingToCart(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setIsAddingToCart(false);
    // Here you would add the actual cart logic
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsWishlisted(!isWishlisted);
  };

  const discountPercentage = book.originalPrice 
    ? Math.round(((book.originalPrice - book.price) / book.originalPrice) * 100)
    : 0;

  return (
    <Card className={cn(
      "group cursor-pointer transition-all duration-300 hover:shadow-elegant hover:-translate-y-1 bg-card overflow-hidden",
      className
    )}>
      <Link to={`/books/${book.id}`}>
        <div className="relative overflow-hidden">
          {/* Book Cover Image */}
          <div className="aspect-[3/4] bg-muted flex items-center justify-center relative">
            <img
              src={book.imageUrl}
              alt={book.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = "https://via.placeholder.com/300x400/f8fafc/64748b?text=Book+Cover";
              }}
            />
            
            {/* Overlay Badges */}
            <div className="absolute top-2 left-2 flex flex-col gap-1">
              {book.isNew && (
                <Badge variant="destructive" className="text-xs">
                  New
                </Badge>
              )}
              {book.isBestseller && (
                <Badge className="bg-accent text-accent-foreground text-xs">
                  Bestseller
                </Badge>
              )}
              {book.isOnSale && discountPercentage > 0 && (
                <Badge variant="destructive" className="text-xs">
                  -{discountPercentage}%
                </Badge>
              )}
            </div>

            {/* Wishlist Button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 bg-background/80 hover:bg-background transition-colors"
              onClick={handleWishlistToggle}
            >
              <Heart 
                className={cn(
                  "h-4 w-4 transition-colors",
                  isWishlisted ? "fill-destructive text-destructive" : "text-muted-foreground"
                )} 
              />
            </Button>

            {/* Quick Add to Cart - Shows on Hover */}
            <div className="absolute inset-x-2 bottom-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <Button
                variant="hero"
                size="sm"
                className="w-full"
                onClick={handleAddToCart}
                disabled={isAddingToCart || book.stock === 0}
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                {isAddingToCart ? "Adding..." : book.stock === 0 ? "Out of Stock" : "Add to Cart"}
              </Button>
            </div>
          </div>
        </div>

        <CardContent className="p-4">
          {/* Genre */}
          <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
            {book.genre}
          </p>

          {/* Title */}
          <h3 className="font-semibold text-foreground line-clamp-2 mb-1 group-hover:text-primary transition-colors">
            {book.title}
          </h3>

          {/* Author */}
          <p className="text-sm text-muted-foreground mb-2">
            by {book.author}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1 mb-3">
            <div className="flex items-center">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={cn(
                    "h-3 w-3",
                    i < Math.floor(book.rating)
                      ? "fill-accent text-accent"
                      : "text-muted-foreground"
                  )}
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">
              {book.rating} ({book.reviewCount})
            </span>
          </div>
        </CardContent>

        <CardFooter className="p-4 pt-0">
          {/* Price */}
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-foreground">
                ${book.price.toFixed(2)}
              </span>
              {book.originalPrice && book.originalPrice > book.price && (
                <span className="text-sm text-muted-foreground line-through">
                  ${book.originalPrice.toFixed(2)}
                </span>
              )}
            </div>
            
            {/* Stock Indicator */}
            {book.stock <= 5 && book.stock > 0 && (
              <Badge variant="outline" className="text-xs">
                Only {book.stock} left
              </Badge>
            )}
          </div>
        </CardFooter>
      </Link>
    </Card>
  );
};